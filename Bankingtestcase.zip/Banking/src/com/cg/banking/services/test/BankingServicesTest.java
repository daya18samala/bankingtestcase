package com.cg.banking.services.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.daoservices.BankingUtility;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class BankingServicesTest {
	private static BankingServices bankservices;
	@BeforeClass
	public static void setUpTestEnv() {
		bankservices = new BankingServicesImpl();
	}
	@Before
	public void setUpMockData() {
		Customer cust1=new Customer( "daya", "samala", "daya@gmail.com", "panCard", new Address(500062, "hyd", "telangana"), new Address(530004, "vizag", "ap"));
		Account acct1=new Account("Savings", 100000);
		Account acct2=new Account("CUrrent",20000);
		Transaction transaction1=new Transaction(BankingUtility.TRANSACTION_ID_COUNTER++, 20000, "IMPS");
		cust1.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		acct1.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		acct2.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		Customer cust2=new Customer( "chandrahas", "vegesna", "cveg@gmail.com", "panCard", new Address(500062, "hyd", "telangana"), new Address(500062, "hyd", "tg"));
		Account acct3=new Account("Savings", 1500000);
		Account acct4=new Account("Current",200000);
		Transaction transaction2=new Transaction(BankingUtility.TRANSACTION_ID_COUNTER++, 200000, "IMPS");
		cust2.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		acct3.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		acct4.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		BankingDAOServicesImpl.customerList.put(cust1.getCustomerId(), cust1);
		BankingDAOServicesImpl.customerList.put(cust2.getCustomerId(), cust2);
		BankingDAOServicesImpl.customerList.get(cust1.getCustomerId()).getAccounts().put(acct1.getAccountNo(), acct1);
		BankingDAOServicesImpl.customerList.get(cust1.getCustomerId()).getAccounts().put(acct2.getAccountNo(), acct2);
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().put(acct3.getAccountNo(), acct3);
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().put(acct4.getAccountNo(), acct4);
		BankingDAOServicesImpl.customerList.get(cust1.getCustomerId()).getAccounts().get(acct1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().get(acct3.getAccountNo()).getTransactions().put(transaction2.getTransactionId(), transaction2);
		BankingDAOServicesImpl.customerList.get(cust1.getCustomerId()).getAccounts().get(acct1.getAccountNo()).setStatus("Active");
		BankingDAOServicesImpl.customerList.get(cust1.getCustomerId()).getAccounts().get(acct1.getAccountNo()).setPinNumber(8842);
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().get(acct3.getAccountNo()).setStatus("Blocked");
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().get(acct3.getAccountNo()).setPinNumber(8843);
		BankingDAOServicesImpl.customerList.get(cust2.getCustomerId()).getAccounts().get(acct4.getAccountNo()).setStatus("Active");
	}
	@Test
	public void testForValidCustomerEntry() throws BankingServicesDownException {
		assertEquals(1002, bankservices.acceptCustomerDetails("daya", "samala", "daya@gmail.com", "panCard", "hyd", "telangana",500062, "vizag", "ap",530234));
	}
	@Test
	public void testForValidCustomerIdAllocation() throws BankingServicesDownException {
		assertNotEquals(1004, bankservices.acceptCustomerDetails("daya", "samala", "daya@gmail.com", "panCard", "hyd", "telangana",500062, "vizag", "ap",530234));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForInvalidAccountEntry() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		assertEquals(155116, bankservices.openAccount(1005, "Savings", 50000));
	}
	@Test
	public void testForValidAccountEntry() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		assertEquals(155116, bankservices.openAccount(1000, "Salary", 50000));
	}
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidAmountEntry() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		assertEquals(155116, bankservices.openAccount(1000, "Savings", -50000));
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidAccountType() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		assertEquals(155116, bankservices.openAccount(1000, "INvalid", 50000));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testDepositAmountForInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(50000, bankservices.depositAmount(1004, 155112, 50000),0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNo() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(50000, bankservices.depositAmount(1000, 155115, 50000),0);
	}
	@Test(expected=AccountBlockedException.class)
	public void testDepositAmountForInactiveAccount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(150000, bankservices.depositAmount(1000, 155113, 50000),0);
	}
	@Test
	public void testDepositAmountForValidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(150000, bankservices.depositAmount(1000, 155112, 50000),0);
	}
	@Test
	public void testWithdrawAmountForValidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1000, 155112, 50000, 8842), 0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testWithdrawAmountForInvalidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1009, 155112, 50000, 8842), 0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountForInvalidAccount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1000, 155120, 50000, 8842), 0);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInsufficientAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1000, 155112, 150000, 8842), 0);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForInvalidPinNumber() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1000, 155112, 50000, 8843), 0);
	}
	@Test(expected=AccountBlockedException.class)
	public void testWithdrawAmountForInvalidStatus() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals(50000, bankservices.withdrawAmount(1001, 155114, 10000, 8843), 0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.fundTransfer(1001, 155115, 1006, 155112, 500000, 8842));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.fundTransfer(1001, 155117, 1000, 155112, 500000, 8842));
	}
	@Test(expected=AccountBlockedException.class)
	public void testFundTransferForInactiveAccount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.fundTransfer(1001, 155114, 1000, 155112, 500000, 8842));
	}
	@Test
	public void testFundTransferForValidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.fundTransfer(1001, 155115, 1000, 155112, 50000, 8842));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Customer expected=new Customer( "daya", "samala", "daya@gmail.com", "panCard", new Address(500062, "hyd", "telangana"), new Address(530004, "vizag", "ap"));
		Customer actual=bankservices.getCustomerDetails(1005);
		assertEquals(expected, actual);
	}
	@Test
	public void testGetCustomerValidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Customer expected=BankingDAOServicesImpl.customerList.get(1000);
		Customer actual=bankservices.getCustomerDetails(1000);
		assertEquals(expected, actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testGetAccountInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Account expected=BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(155112);
		Account actual=bankservices.getAccountDetails(1005, 155112);
		assertEquals(expected, actual);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountInvalidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Account expected=BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(155112);
		Account actual=bankservices.getAccountDetails(1000, 155115);
		assertEquals(expected, actual);
	}
	@Test
	public void testGetAccountValidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Account expected=BankingDAOServicesImpl.customerList.get(1000).getAccounts().get(155112);
		Account actual=bankservices.getAccountDetails(1000, 155112);
		assertEquals(expected, actual);
	}
	@Test
	public void testGenerateNewPinForValidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		int expected=8842;
		int actual=bankservices.generateNewPin(1000, 155112);
		assertNotEquals(expected, actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testGenerateNewPinForInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		int expected=8842;
		int actual=bankservices.generateNewPin(1005, 155112);
		assertNotEquals(expected, actual);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGenerateNewPinForInvalidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		int expected=8842;
		int actual=bankservices.generateNewPin(1000, 155115);
		assertNotEquals(expected, actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testChangePinForInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.changeAccountPin(1005, 155112, 8842, 7515));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testChangePinForInvalidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.changeAccountPin(1000, 155115, 8842, 7515));
	}
	@Test
	public void testChangePinForValidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.changeAccountPin(1000, 155112, 8842, 7515));
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangePinForInvalidPin() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue(bankservices.changeAccountPin(1000, 155112, 8843, 7515));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testAcountStatusForInvalidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals("Active", bankservices.accountStatus(1005, 155112));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testAcountStatusForInvalidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals("Active", bankservices.accountStatus(1000, 155115));
	}
	@Test
	public void testAcountStatusForVadlidDetailsActive() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals("Active", bankservices.accountStatus(1000, 155112));
	}
	@Test(expected=AccountBlockedException.class)
	public void testAcountStatusForBlockedAccount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertEquals("Blocked", bankservices.accountStatus(1001, 155114));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testCloseAcountForInvadlidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue( bankservices.closeAccount(1005, 155112));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testCloseAcountForInvadlidAccountId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue( bankservices.closeAccount(1000, 155114));
	}
	@Test
	public void testCloseAcountVadlidDetails() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue( bankservices.closeAccount(1000, 155113));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testRemoveCustomerForInvadlidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue( bankservices.removeCustomer(1005));
	}
	@Test
	public void testCloseAcountInvadlidCustomerId() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		assertTrue( bankservices.removeCustomer(1001));
	}
	@After
	public void tearDownMockData() {
		BankingDAOServicesImpl.customerList.clear();
		BankingUtility.ACCOUNT_ID_COUNTER=155112;
		BankingUtility.CUSTOMER_ID_COUNTER=1000;
		BankingUtility.TRANSACTION_ID_COUNTER=254789;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		bankservices=null;
	}
}
