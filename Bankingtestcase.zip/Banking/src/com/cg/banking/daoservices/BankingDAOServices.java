package com.cg.banking.daoservices;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public interface BankingDAOServices {
	int insertCustomer(Customer customer);
	long insertAccount(int customerId,Account account);
	boolean updateAccount(int customerId,Account account);
	int generatePin(int customerId,Account account);
	boolean deleteCustomer(int customerId);
	Customer getCustomer(int customerId);
	Account getAccount(int customerId,int accountNo);
	List<Customer> getCustomers();
	List<Account> getAccounts(int customerId);
	List<Transaction> getTransactions(int customerId,int accountNo);
	boolean insertTransaction(int customerId, int accountNo, Transaction transaction);
	boolean deleteAccount(int customerId, int accountNo);
}
