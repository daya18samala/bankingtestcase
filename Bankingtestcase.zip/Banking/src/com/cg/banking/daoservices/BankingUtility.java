package com.cg.banking.daoservices;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=1000;
	public static int ACCOUNT_ID_COUNTER=155112;
	public static int TRANSACTION_ID_COUNTER=254789;
	
}
