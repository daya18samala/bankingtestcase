package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
public class BankingDAOServicesImpl implements BankingDAOServices {
	public static HashMap<Integer, Customer> customerList=new HashMap<>();
	Random rand=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		customerList.put(customer.getCustomerId(), customer);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		customerList.get(customerId).getAccounts().put(account.getAccountNo(), account);
		account.setStatus("ACTIVE");
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
	customerList.get(customerId).getAccounts().put(account.getAccountNo(),account);
			return true ;
	}
	@Override
	public int generatePin(int customerId, Account account) { 
			int accountNo=account.getAccountNo();
			getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9999) + 1000);
			return getAccount(customerId, accountNo).getPinNumber(); 
	}
	@Override
	public boolean insertTransaction(int customerId, int accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		customerList.get(customerId).getAccounts().get(accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		Customer cust=customerList.remove(customerId);
		if(cust==null)
			return false;
		return true;
	}
	@Override
	public boolean deleteAccount(int customerId, int accountNo) {
		Account account=customerList.get(customerId).getAccounts().remove(accountNo);
		if(account==null)
			return false;
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
	}
	@Override
	public Account getAccount(int customerId, int accountNo) {
		return customerList.get(customerId).getAccounts().get(accountNo);
	}
	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<Customer>(customerList.values());
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<Account>(customerList.get(customerId).getAccounts().values());
	}
	@Override
	public List<Transaction> getTransactions(int customerId, int accountNo) {
		return new ArrayList<Transaction>(customerList.get(customerId).getAccounts().get(accountNo).getTransactions().values());
	}
}
